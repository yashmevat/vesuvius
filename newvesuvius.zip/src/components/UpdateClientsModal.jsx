"use client";

import { useState, useEffect } from "react";
import toast from "react-hot-toast";

export default function UpdateClientsModal({ managerId, currentClients, isOpen, onClose }) {
    const [clients, setClients] = useState([]);
    const [selectedClients, setSelectedClients] = useState([]);

   useEffect(() => {
  // Load all clients
  fetch("/api/superadmin/clients/list")
    .then((res) => res.json())
    .then((data) => setClients(data));

  // Ensure currentClients is always an array
  const selected = Array.isArray(currentClients)
    ? currentClients.map(Number)
    : currentClients
    ? [Number(currentClients)]
    : [];

  setSelectedClients(selected);
}, [currentClients]);



    const handleCheckboxChange = (clientId) => {
        if (selectedClients.includes(clientId)) {
            setSelectedClients(selectedClients.filter((id) => id !== clientId));
        } else {
            setSelectedClients([...selectedClients, clientId]);
        }
    };

    const handleSubmit = async () => {
        try {
            const res = await fetch("/api/superadmin/managers/update-clients", {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ managerId, clientIds: selectedClients.map(Number) }),
            });

            const data = await res.json();
            if (res.ok) {
                toast.success(data.message || "Clients updated successfully");
                onClose(); // Close modal
            } else {
                toast.error(data.error || "Failed to update clients");
            }
        } catch (error) {
            console.error(error);
            toast.error("Something went wrong");
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-md text-white">
                <h2 className="text-xl font-bold mb-4">Update Clients</h2>

                <div className="max-h-64 overflow-y-auto mb-4">
                    {clients.map((client) => (
                        <label key={client.id} className="flex items-center mb-2">
                            <input
                                type="checkbox"
                                className="mr-2"
                                checked={selectedClients.includes(Number(client.id))}
                                onChange={() => handleCheckboxChange(Number(client.id))}
                            />

                            {client.name}
                        </label>
                    ))}
                </div>

                <div className="flex justify-end space-x-2">
                    <button
                        className="bg-gray-500 hover:bg-gray-600 px-4 py-2 rounded"
                        onClick={onClose}
                    >
                        Cancel
                    </button>
                    <button
                        className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded"
                        onClick={handleSubmit}
                    >
                        Update
                    </button>
                </div>
            </div>
        </div>
    );
}
