import { NextResponse } from "next/server";
import db from "@/lib/db";

export async function POST(req) {
  try {
    const { managerId, selectedClient, pdfUrl } = await req.json();

    if (!managerId || !selectedClient || !pdfUrl) {
      return NextResponse.json({ success: false, message: "Missing fields" }, { status: 400 });
    }

    await db.execute(
      "INSERT INTO weekly_reports (manager_id, client_id, pdf_url) VALUES (?, ?, ?)",
      [managerId, selectedClient, pdfUrl]
    );

    return NextResponse.json({ success: true, message: "Weekly report saved" });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
