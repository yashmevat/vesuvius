import db from "@/lib/db";

export async function PATCH(req) {
  const connection = await db.getConnection(); // if using mysql2/promise
  try {
    const { managerId, clientIds } = await req.json();

    if (!managerId || !Array.isArray(clientIds)) {
      return Response.json({ error: "managerId and clientIds are required" }, { status: 400 });
    }

    const validClientIds = clientIds.filter(cid => cid);

    await connection.beginTransaction();

    // Delete existing
    await connection.query("DELETE FROM manager_clients WHERE manager_id = ?", [managerId]);

    // Insert new
    if (validClientIds.length > 0) {
      const values = validClientIds.map(cid => [managerId, cid]);
      await connection.query("INSERT INTO manager_clients (manager_id, client_id) VALUES ?", [values]);
    }

    await connection.commit();

    return Response.json({ message: "Manager clients updated successfully" });
  } catch (error) {
    await connection.rollback();
    console.error("❌ Update clients error:", error);
    return Response.json({ error: error.message || "Failed to update clients" }, { status: 500 });
  } finally {
    connection.release();
  }
}
