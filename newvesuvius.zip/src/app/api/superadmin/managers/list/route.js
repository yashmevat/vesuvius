import db from "@/lib/db";

export async function GET() {
  try {
    const [rows] = await db.query(`
      SELECT 
        u.id,
        u.name,
        u.email,
        u.workforce_limit,
        IFNULL(GROUP_CONCAT(c.id), '') AS client_ids,
        IFNULL(GROUP_CONCAT(c.name), '') AS client_names
      FROM users u
      LEFT JOIN manager_clients mc ON mc.manager_id = u.id
      LEFT JOIN clients c ON mc.client_id = c.id
      WHERE u.role = 'manager'
      GROUP BY u.id, u.name, u.email, u.workforce_limit
    `);

    // Convert comma-separated strings to arrays
    const result = rows.map((row) => ({
      ...row,
      client_ids: row.client_ids ? row.client_ids.split(',').map(Number) : [],
      client_names: row.client_names ? row.client_names.split(',') : [],
    }));

    return Response.json(result);
  } catch (error) {
    console.error("❌ Error fetching managers:", error);
    return Response.json({ error: "Failed to fetch managers" }, { status: 500 });
  }
}
