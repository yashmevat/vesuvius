"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function UserLogin() {
  const [form, setForm] = useState({ email: "", password: "", role: "" });
  const router = useRouter();

  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await fetch("/api/auth/user-login", {
      method: "POST",
      body: JSON.stringify(form),
    });
    const data = await res.json();

    if (res.ok) {
      localStorage.setItem("token", data.token);
      localStorage.setItem("userId", data.id)
      if (data.role === "manager") {
        router.push("/manager/dashboard");
      } else {
        router.push("/workforce/dashboard");
      }
    } else {
      alert(data.error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      <form
        onSubmit={handleLogin}
        className="bg-gray-900/60 backdrop-blur-lg p-8 rounded-xl shadow-lg w-full max-w-sm space-y-5 border border-gray-700"
      >
        <h1 className="text-2xl font-bold text-center text-green-400">
          Manager / Workforce Login
        </h1>

        <input
          className="border border-gray-700 bg-gray-800 text-white p-3 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 placeholder-gray-400"
          placeholder="Email"
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />

        <input
          className="border border-gray-700 bg-gray-800 text-white p-3 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 placeholder-gray-400"
          placeholder="Password"
          type="password"
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />

        <select
          className="border border-gray-700 bg-gray-800 text-white p-3 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          onChange={(e) => setForm({ ...form, role: e.target.value })}
        >
          <option value="">Select Role</option>
          <option value="manager">Manager</option>
          <option value="workforce">Workforce</option>
        </select>
        <Link
          href="/auth/forgotpassword"
          className="text-sm text-green-500 hover:text-green-700 font-medium transition-colors duration-200 underline hover:underline-offset-2"
        >
          Forgot Password?
        </Link>
        <button
          type="submit"
          className="bg-green-500 hover:bg-green-600 transition-colors text-white px-4 py-3 rounded-lg w-full font-semibold shadow-md"
        >
          Login
        </button>
      </form>
    </div>

  );
}
