"use client";
import SuperAdminNavbar from "@/components/SuperadminNavbar";
import { useEffect, useState } from "react";

export default function ReportsList() {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    fetch("/api/superadmin/reports/pending")
      .then(res => res.json())
      .then(data => setReports(data));
  }, []);

  const updateStatus = async (id, status) => {
    await fetch(`/api/superadmin/reports/${status}`, {
      method: "POST",
      body: JSON.stringify({ id })
    });
    setReports(reports.filter(r => r.id !== id));
  };

  return (
    <div>
      <SuperAdminNavbar/>
<div className="min-h-screen flex items-center justify-center bg-gray-900 p-6">
  <div className="bg-gray-800 w-full max-w-6xl p-8 rounded-2xl shadow-lg border border-gray-700 text-white">
    <h1 className="text-3xl font-bold mb-6 text-center text-green-400">Pending Reports</h1>

    <div className="overflow-x-auto rounded-lg">
      <table className="w-full border-collapse border border-gray-700">
        <thead>
          <tr className="bg-gray-700 text-white">
            <th className="p-3 border border-gray-600 text-left">Workforce</th>
            <th className="p-3 border border-gray-600 text-left">Text</th>
            <th className="p-3 border border-gray-600 text-left">Image</th>
            <th className="p-3 border border-gray-600 text-left">Actions</th>
          </tr>
        </thead>
        <tbody>
          {reports.length > 0 ? (
            reports.map((r) => (
              <tr
                key={r.id}
                className="hover:bg-gray-700 transition-colors cursor-default"
              >
                <td className="p-3 border border-gray-600">{r.workforce_name}</td>
                <td className="p-3 border border-gray-600">{r.text}</td>
                <td className="p-3 border border-gray-600">
                  <img
                    src={r.image_url}
                    alt="report image"
                    className="w-20 rounded-md object-cover"
                  />
                </td>
                <td className="p-3 border border-gray-600 flex gap-2">
                  <button
                    onClick={() => updateStatus(r.id, "approve")}
                    className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded transition"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => updateStatus(r.id, "reject")}
                    className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded transition"
                  >
                    Reject
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                colSpan="4"
                className="text-center p-6 text-gray-400 border border-gray-600"
              >
                No pending reports found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  </div>
</div>

    </div>
  );
}
