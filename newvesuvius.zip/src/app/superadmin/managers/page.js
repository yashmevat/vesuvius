"use client";
import SuperAdminNavbar from "@/components/SuperadminNavbar";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { PlusCircle, Users, Edit, Trash2 } from "lucide-react";
import UpdateClientsModal from "@/components/UpdateClientsModal";
import UpdateWorkforceModal from "@/components/UpdateWorkforceModal";
import UpdateManagerModal from "@/components/UpdateManagerModal";
import DeleteManagerModal from "@/components/DeleteManagerModal";

export default function ManagersList() {
  const [managers, setManagers] = useState([]);
  const [modalType, setModalType] = useState(null); // clients, workforce, update, delete
  const [selectedManager, setSelectedManager] = useState(null);
  const router = useRouter();

  const fetchManagers = () => {
    fetch("/api/superadmin/managers/list")
      .then((res) => res.json())
      .then((data) => setManagers(data));
  };

  useEffect(() => {
    fetchManagers();
  }, []);

  const openModal = (type, manager) => {
    setSelectedManager(manager);
    setModalType(type);
  };

  const closeModal = () => {
    fetchManagers();
    setModalType(null);
    setSelectedManager(null);
  };

  return (
    <div>
      <SuperAdminNavbar />
      <div className="min-h-screen flex items-center justify-center bg-gray-900 p-6">
        <div className="bg-gray-800 w-full max-w-6xl p-8 rounded-2xl shadow-lg border border-gray-700 text-white">
          <h1 className="text-3xl font-bold mb-6 text-center">Managers</h1>

          <div className="flex justify-end mb-4">
            <a
              href="/superadmin/managers/add"
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg shadow transition"
            >
              + Add Manager
            </a>
          </div>

          <div className="overflow-x-auto rounded-lg">
            <table className="w-full border-collapse border border-gray-700">
              <thead>
                <tr className="bg-gray-700 text-white">
                  <th className="p-3 border border-gray-600 text-left">Name</th>
                  <th className="p-3 border border-gray-600 text-left">Email</th>
                  <th className="p-3 border border-gray-600 text-left">Clients</th>
                  <th className="p-3 border border-gray-600 text-left">Workforce Limit</th>
                  <th className="p-3 border border-gray-600 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {managers.length > 0 ? (
                  managers.map((m) => (
                    <tr key={m.id} className="hover:bg-gray-700 transition-colors">
                      <td className="p-3">{m.name}</td>
                      <td className="p-3">{m.email}</td>
                      <td className="p-3">{m.client_names?.length ? m.client_names.join(", ") : "No Clients"}</td>
                      <td className="p-3">{m.workforce_limit}</td>
                      <td className="p-3 flex space-x-2 justify-center">
                        <button onClick={() => openModal("clients", m)} className="bg-green-600 hover:bg-green-700 px-3 py-1 rounded-lg">
                          Clients
                        </button>
                        <button onClick={() => openModal("workforce", m)} className="bg-yellow-500 hover:bg-yellow-600 px-3 py-1 rounded-lg text-black">
                          <PlusCircle size={16} /> Workforce
                        </button>
                        <button onClick={() => openModal("update", m)} className="bg-blue-500 hover:bg-blue-600 px-3 py-1 rounded-lg">
                          <Edit size={16} /> Update
                        </button>
                        <button onClick={() => openModal("delete", m)} className="bg-red-500 hover:bg-red-600 px-3 py-1 rounded-lg">
                          <Trash2 size={16} /> Delete
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="text-center p-4 text-gray-400">No managers found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modals */}
      {modalType === "clients" && (
        <UpdateClientsModal isOpen={true} onClose={closeModal} managerId={selectedManager.id} currentClients={selectedManager.client_ids} />
      )}
      {modalType === "workforce" && (
        <UpdateWorkforceModal isOpen={true} onClose={closeModal} managerId={selectedManager.id} currentLimit={selectedManager.workforce_limit} />
      )}
      {modalType === "update" && (
        <UpdateManagerModal isOpen={true} onClose={closeModal} manager={selectedManager} />
      )}
      {modalType === "delete" && (
        <DeleteManagerModal isOpen={true} onClose={closeModal} manager={selectedManager} />
      )}
    </div>
  );
}
