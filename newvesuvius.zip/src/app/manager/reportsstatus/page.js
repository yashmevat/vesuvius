import ManagerNavbar from '@/components/ManagerNavbar'
import React from 'react'

const ReportsStatus = () => {
  return (
    <div>
        <ManagerNavbar/>
      reports status
    </div>
  )
}

export default ReportsStatus
