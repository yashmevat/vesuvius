import ManagerNavbar from '@/components/ManagerNavbar'
import React from 'react'

const ManagerDashboard = () => {
  return (
    <div>
      <ManagerNavbar/>
        manager dashboard
    </div>
  )
}

export default ManagerDashboard
