import Navbar from '@/components/Navbar'
import React from 'react'

const WorkForceDashboard = () => {
  return (
    <div>

      <Navbar />
      <div className="bg-gray-900 text-white shadow-md border-b border-gray-700 min-h-screen">
      </div>
    </div>
  )
}

export default WorkForceDashboard
